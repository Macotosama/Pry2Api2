    
    // config for your database
    exports.config = {
    
        user: 'db2020',
        password: 'db2020',
        server: 'LAPTOP-QAF7PFG0\\MSSQLSERVER01',
        database: 'BaseSecundaria',
        options: {
            encrypt: false,
           "enableArithAbort": true
            }
    };
    
    exports.webPort = 8100;
    