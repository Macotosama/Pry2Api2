var db = require('../baseDeDatos/db');




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

exports.getpTotalesDeFacturas = function(req, resp){
    const par = "'"
    const coma = ","
    var XD = req.body;
    console.log(XD)
    db.executeSQL("Execute pTotalesDeFacturas "+par+(XD.categoria)+par+""+coma+par+(XD.fecha1)+par+""+coma+par+(XD.fecha2)+par+""+coma+par+(XD.sede)+par+"".toString(),function (data, err){
        if(err){
            console.log(err)
        }else{
           
            resp.json(data.recordset)
            
        }
    });
};

exports.getpTotalesDeFacturasCartago = function(req, resp){
    const par = "'"
    const coma = ","
    var XD = req.body;
    console.log(XD)
    db.executeSQL("Execute pTotalesDeFacturasCartago "+par+(XD.categoria)+par+""+coma+par+(XD.fecha1)+par+""+coma+par+(XD.fecha2)+par+""+coma+par+(XD.sede)+par+"".toString(),function (data, err){
        if(err){
            console.log(err)
        }else{
           
            resp.json(data.recordset)
            
        }
    });
};


exports.getpTotalConsolidado = function(req, resp){
    const par = "'"
    const coma = ","
    var XD = req.body;
    db.executeSQL("Execute pTotalConsolidado "+par+(XD.fecha1)+par+""+coma+par+(XD.fecha2)+par+""+coma+par+(XD.categoria)+par+"".toString(),function (data, err){
        if(err){
            console.log(err)
        }else{
           
            resp.json(data.recordset)
            
        }
    });
};


exports.getpBuscarProductoCategoriaEnInvenatrio = function(req, resp){
    const par = "'"
    const coma = ","

    db.executeSQL("Execute pBuscarProductoCategoriaEnInvenatrioCartago "+par+(req.params.par1)+par+""+coma+par+(req.params.par2)+par+"".toString(),function (data, err){
        if(err){
            console.log(err)
        }else{
           
            resp.json(data.recordset)
            
        }
    });
};

exports.getpBuscarProductoCategoriaEnInvenatrioLimon = function(req, resp){
    const par = "'"
    const coma = ","

    db.executeSQL("Execute pBuscarProductoCategoriaEnInvenatrioLimon "+par+(req.params.par1)+par+""+coma+par+(req.params.par2)+par+"".toString(),function (data, err){
        if(err){
            console.log(err)
        }else{
           
            resp.json(data.recordset)
            
        }
    });
};


exports.getpRetornoInventarioCartago = function(req, resp){
    const par = "'"

    db.executeSQL("Execute pRetornoInventarioCartago",function (data, err){
        if(err){
            console.log(err)
        }else{   
            resp.json(data.recordset)
        }
    });
};

exports.getpRetornoInventariLimon = function(req, resp){
    const par = "'"

    db.executeSQL("Execute pRetornoInventariLimon",function (data, err){
        if(err){
            console.log(err)
        }else{   
            resp.json(data.recordset)
        }
    });
};

