var express = require('express');
var persons = require('./controller/Persons');
const bodyParser = require('body-parser');
const cors = require('cors')
var configPortAndSettings = require('./servConfig/config')


var app = express();



app.use(bodyParser.json())
app.use(cors())

///
app.get('/getpBuscarProductoCategoriaEnInvenatrio/:par1/:par2',persons.getpBuscarProductoCategoriaEnInvenatrio)
app.post('/getpTotalesDeFacturas',persons.getpTotalesDeFacturas)
app.post('/getpTotalConsolidado',persons.getpTotalConsolidado)
app.post('/getpTotalesDeFacturasCartago',persons.getpTotalesDeFacturasCartago)
app.post('/getpBuscarProductoCategoriaEnInvenatrioLimon',persons.getpBuscarProductoCategoriaEnInvenatrioLimon)
app.get('/getpRetornoInventarioCartago',persons.getpRetornoInventarioCartago)
app.get('/getpRetornoInventariLimon',persons.getpRetornoInventariLimon)
var server = app.listen(configPortAndSettings.webPort, function () {
    console.log(`Server is running at ${configPortAndSettings.webPort}`);
});

